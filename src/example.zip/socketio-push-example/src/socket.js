const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http);

io.on("connection", (socket) => {
    console.log("Connected");
    socket.on('disconnect', () => {
            console.log("Disconnected");
    });

    socket.on('Front-end_src_recipe.js', (msg) => {
            console.log("get file");
            io.emit("resp", "Thankyou");
            console.log(msg);
    //      processLineByLine(msg);
    });
});