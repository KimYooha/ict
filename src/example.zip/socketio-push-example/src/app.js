const express = require("express");
const app = express();
const fs = require('fs');
const http = require("http").createServer(app);
const io = require("socket.io")(http);
const readline = require('readline');
const path = require('path')

function parse_vba(value) {
    var fmu = value & 0x3
    var plane = (value >> 2) & 0x3
    var lFim = (value >> 4) & 0x1
    var diePageInBlk = (value >> 5) & 0x1fff
    var block = (value >> 18) & 0x3ff
    var hFim = (value >> 28) & 0x1
    var dieInFim = (value >> 29) & 0x3
    var fim_high = (value >> 31) & 0x1
    console.log(value);
    console.log(`VBA => hFim : ${hFim}, lFim : ${lFim}, dieInFim : ${dieInFim}, Block : ${block}, Page : ${diePageInBlk}, Plane : ${plane}, Fmu : ${fmu}`);
}

async function processLineByLine(filename) {
	console.log("Read File..");

	const fileStream = fs.createReadStream(filename);
	const rl = readline.createInterface({
		input: fileStream,
		crlfDelay: Infinity
	});

	var start_vba = 0;
	var end_vba = 0;

	for await (const line of rl) {
		if(line.includes("From DGM RUN peek") && line.includes("msgType 0xa") && line.includes("VBA")){
			// Each line in input.txt will be successively available here as `line`.
			// console.log(`Line from file: ${line}`);

			var data = line.split(" ");
			var index = data.indexOf("VBA");
			if(index !== -1){
				console.log(`Line from file: ${index}`);
				var vba = parseInt(data[index + 1], 16);
				if (start_vba == 0) {
					start_vba = vba;
				}

				end_vba = vba;
				parse_vba(vba);
				console.log(vba);
			}
		}
	}

	console.log(`Start VBA : 0x${start_vba.toString(16)} End VBA : 0x${end_vba.toString(16)}`);

	io.emit('result', {
		test_case : "test1",
		test_result : "OK",
		start_page : start_vba,
		end_page : end_vba,
	});
}

// 소켓 서버 구동
io.on("connection", (socket) => {
	console.log("Connected");
	socket.on('disconnect', () => {
		console.log("Disconnected");
	});

	socket.on('file', (msg) => {
		console.log("get file");
		io.emit("resp", "Thankyou");
		console.log(msg);
	//	processLineByLine(msg);
	});
});

app.use('/script', express.static(path.join(__dirname, 'script')))

// 클라이언트 화면 노출
app.get("/", (req, res) => {
	res.sendFile(__dirname + "/index.html");
});

// push api 정의
app.get("/push", (req, res) => {
	console.log(res);
	// 소켓 연결된 모든 클라이언트에 전송
	io.emit("noti");
	processLineByLine(res);
	// 화면 출력
	res.send("푸시!!");
});

// express 서버 구동
http.listen(3000, () => {
	console.log("listening on *:3000");
});
