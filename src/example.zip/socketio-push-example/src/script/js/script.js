function drawTable(width, height){
	digit = height;

	var data = "";
	/* header */
	data += "<thead>";
	data += "<tr>";

	data += "<td>" + "</td>"
	for (var i = 0; i < width - 1; i++) {
		data += "<th>" + "Plane" + i % 4 + "</th>";
	}

	data += "</thead>";
	data += "</tr>";

	document.getElementById('data').innerHTML = data;
}

function add_row_column(page) {
	var my_tbody = document.getElementById('my-tbody');
	var row = my_tbody.insertRow( my_tbody.rows.length ); // 하단에 추가
	var cell0 = row.insertCell(0);
	var cell1 = row.insertCell(1);
	var cell2 = row.insertCell(2);
	var cell3 = row.insertCell(3);
	var cell4 = row.insertCell(4);
	var cell5 = row.insertCell(5);
	var cell6 = row.insertCell(6);
	var cell7 = row.insertCell(7);
	var cell8 = row.insertCell(8);
	var cell9 = row.insertCell(9);
	var cell10 = row.insertCell(10);
	var cell11 = row.insertCell(11);
	var cell12 = row.insertCell(12);
	var cell13 = row.insertCell(13);
	var cell14 = row.insertCell(14);
	var cell15 = row.insertCell(15);
	var cell16 = row.insertCell(16);
	cell0.innerHTML = page;
	cell0.style.backgroundColor = "#E0E0E0";
	cell1.style.backgroundColor = "#E0E0E0";
	cell1.innerHTML = 'plane1';
	cell2.style.backgroundColor = "#E0E0E0";
	cell2.innerHTML = 'plane2';
	cell3.style.backgroundColor = "#E0E0E0";
	cell3.innerHTML = 'plane3';
	cell4.style.backgroundColor = "#E0E0E0";
	cell4.innerHTML = 'plane4';
}

function add_row(page) {
	var my_tbody = document.getElementById('my-tbody');
	var row = my_tbody.insertRow( my_tbody.rows.length ); // 하단에 추가
	var cell0 = row.insertCell(0);
	cell0.innerHTML = page;
	cell0.style.backgroundColor = "#E0E0E0";
}

function displayTable(width, height){
	digit = height;

	var data = "";
	/* header */
	data += "<thead>";
	data += "<tr>";

	data += "<td>" + "</td>"
	for (var i = 0; i < width - 1; i++) {
		data += "<th>" + "Plane" + i % 4 + "</th>";
	}

	data += "</thead>";
	data += "</tr>";

	/* body */
	for(var i = 0; i < digit; i++) {
		data += "<tr>";

		data += "<td>" + "LWL" + i + "</td>"
		for(var j = 0; j < width - 1; j++){

			data += "<td>"+ "Write" +"</td>";
		}
		data += "</tr>";
	}

	document.getElementById('data').innerHTML = data;
}

function displayTable2(width, height){
	document.write('<table border="1">');

	// header
	document.write('<thead>');
	document.write('<tr>');
	for(let i = 2; i <= 9; i++) {
		document.write('<th>' + i + '단 </th>');
	}
	document.write('</tr>');
	document.write('</thead>');

	// body
	document.write('<tbody>');
	for(let i = 1; i <= 9; i++) {
		document.write('<tr>');
		for(let j = 2; j <= 9; j++) {
			document.write('<td>' + j + ' * ' + i + ' = ' + (j*i) + '</td>');
		}
		document.write('</tr>');
	}
	document.write('</tbody>');

	document.write('</table>');
}

function displayVBA(vba) {
	document.write(vba);
}

function add_column() {
    const table = document.getElementById('my-tbody');
	for(let i = 0; i < table.rows.length; i++)  {
		const newCell =table.rows[i].insertCell(-1);
		newCell.innerText = 'New';
	}
}
