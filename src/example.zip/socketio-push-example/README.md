## 가이드
### 저장소 코드 내려받기
```
git clone https://github.com/okchangwon/socketio-push-example.git
```

### 설치
```
cd socketio-push-example
npm install
```

### 서버 구동
```
node ./src/app.js
또는
npm run start
```

### 화면 접속
http://localhost:3000
